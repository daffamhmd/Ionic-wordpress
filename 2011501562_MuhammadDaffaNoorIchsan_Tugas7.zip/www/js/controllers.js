angular.module('starter.controllers',[])
.controller('MainCtrl', function($scope, $window, $state) {
    $scope.doBack = function(){
        $window.history.back();
    };
})
.controller('NewsCtrl', function($scope, $http ,$window, $state) {
    $http.get("https://smkbinainformatika.sch.id/wp-json/wp/v2/posts")
    .then(function (response){
        $scope.posts = response.data;
    });
    $scope.doAbout = function() {
        $window.history.back();
    };
})
.controller('DetailNewsCtrl', function($scope, $http ,$stateParams, $state, $window) {
    $http.get("https://smkbinainformatika.sch.id/wp-json/wp/v2/posts/"+$stateParams.id)
    .then(function (response){
        $scope.posts = response.data;
    });
    $scope.doAbout = function() {
        $window.history.back();
    };
})
.controller('MapCtrl', function($scope, $ionicLoading, $compile, $state, $window) {
    window.initMap = function () {
        var myLatlng = new google.maps.LatLng(-6.2815783,106.7242388);

        var mapOptions = {
            center: myLatlng,
            zoom: 16,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map (document.getElementById ("map"),
        mapOptions);
        //Marker + infowindow + angularjs compiled ng-click
        var contentString = "<div><a ng-click='clickTest ()'>Universitas Budi Luhur <br/>+62-21-5853753</a></div>";
        var compiled = $compile(contentString) ($scope) ;
        var infowindow = new google.maps.InfoWindow({
            content: compiled[0]

        });
        var marker = new google.maps.Marker ({
            position: myLatlng,
            map: map,
            title: 'Universitas Budi Luhur'
        });
        google.maps.event.addListener(marker, 'click', function() {
            infowindow.open(map,marker);
        });

        $scope.map = map;
    }
    google.maps.event.addDomListener(window, 'load', initMap);
    initMap();
    $scope.doAbout = function(){
        $window.history.back();
    };
})
